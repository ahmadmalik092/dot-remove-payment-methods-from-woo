<?php if ( ! defined( 'ABSPATH' ) ){ exit; }else{ clearstatcache(); }
/**
 * Plugin Name:       		dot remove payment methods
 * Description:       		This plugin will help you ADJUST woocommerce payment GETWAYS 
 * Version:					1.0.0
 * Requires at least: 		4.9
 * Requires PHP:      		7.2
 * Author:            		Machination Tech
 * Author URI:        		https://machination.tech
 * License:           		GPL v2 or later
 * License URI:       		https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       		dot-remove-payment-methods
 * Domain Path:       		/languages
 * WC requires at least:	3.4
 * WC tested up to: 		5.3
 */

/**
 * If this file is called directly, abort.
 *
 * @since 1.0.0
 */
if ( !defined( 'WPINC' ) ) {
	die;
}

add_filter( 'woocommerce_available_payment_gateways', 'dot_adjust_payment_methods_in_checkout' );

function dot_adjust_payment_methods_in_checkout( $available_gateways ) {
    // Not in backend (admin)
    // if( is_admin() ) 
    //     return $available_gateways;
    
    if(!is_checkout()){
        //echo "not checkout";
        return $available_gateways;
    }
    
    global $woocommerce;
    
    $is_standard_checkout = false; //aks-flow-trial, global
    $is_seo_checkout = false; //checkout-woo, seo-foundation-ebook-checkout

    global $wp;
    //echo $wp->request;
    if($wp->request == "cartflows_step/checkout-page"){
    	$is_standard_checkout = true;
        $is_seo_checkout = false;
        unset($available_gateways['poli']);
        //echo "standard checkout";
    }
    elseif($wp->request == "cartflows_step/checkout-woo"){
    	$is_standard_checkout = false;
        $is_seo_checkout = true;
        
        //unset($available_gateways['poli']);
        $filtered_gateways = array_intersect_key($available_gateways,
                    	array_flip( 
                      		array('spyr_firstdata_gateway', 'poli')
               			)
					);
        return $filtered_gateways;
        
        //echo "custom checkout";
    }
    elseif($wp->request == "cartflows_step/seo-foundation-ebook-checkout"){
    	$is_standard_checkout = false;
        $is_seo_checkout = true;
        
        //unset($available_gateways['qisst_pay']);
        $filtered_gateways = array_intersect_key($available_gateways,
                    	array_flip( 
                      		array('spyr_firstdata_gateway', 'poli')
               			)
					);
        return $filtered_gateways;
        //echo "ebook checkout";
    }
    else{
    	unset($available_gateways['poli']);
    	//echo "unknown checkout";
    }
    return $available_gateways;
}